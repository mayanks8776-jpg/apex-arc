import { useEffect, useState } from 'react';

const NAV_LINKS = [
  { label: 'About Us', href: '#about' },
  { label: 'Our Services', href: '#services' },
  { label: 'Portfolio', href: '#portfolio' },
  { label: 'Process', href: '#stats' },
  { label: 'Contacts', href: '#contact' },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 h-16 flex items-center justify-between px-8 lg:px-12 transition-all duration-300 ${
        scrolled
          ? 'bg-[rgba(249,246,240,0.95)] backdrop-blur-md border-b border-[#e0dcd3]'
          : 'bg-transparent'
      }`}
    >
      <a
        href="#"
        className={`font-display text-xl transition-colors duration-300 ${
          scrolled ? 'text-[#1a1a1a]' : 'text-white'
        }`}
        onClick={(e) => {
          e.preventDefault();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      >
        APEX Arc
      </a>

      <nav className="hidden md:flex items-center gap-8">
        {NAV_LINKS.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={(e) => handleClick(e, link.href)}
            className={`font-body text-sm font-normal transition-colors duration-300 hover:opacity-70 ${
              scrolled ? 'text-[#1a1a1a]' : 'text-white'
            }`}
          >
            {link.label}
          </a>
        ))}
      </nav>
    </header>
  );
}
