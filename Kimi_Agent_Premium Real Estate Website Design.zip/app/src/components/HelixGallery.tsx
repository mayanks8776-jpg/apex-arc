import { useRef, useMemo, useCallback } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useTexture } from '@react-three/drei';
import * as THREE from 'three';

const IMAGE_PATHS = Array.from({ length: 18 }, (_, i) =>
  `/images/hero-helix-${i + 1}.jpg`
);

const TURNS = 4;
const RADIUS = 3.5;
const NUM_ITEMS = 36;
const STRAND_HEIGHT = 10;

interface HelixItemData {
  angle: number;
  y: number;
  xOffset: number;
  imageIndex: number;
}

function HelixMesh({
  texture,
  data,
  groupRef,
}: {
  texture: THREE.Texture;
  data: HelixItemData;
  groupRef: React.RefObject<THREE.Group | null>;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.MeshBasicMaterial>(null);

  useFrame(() => {
    if (!meshRef.current || !groupRef.current) return;

    const currentAngle = data.angle + groupRef.current.rotation.y + data.xOffset;
    meshRef.current.position.x = Math.cos(currentAngle) * RADIUS;
    meshRef.current.position.y = data.y;
    meshRef.current.position.z = Math.sin(currentAngle) * RADIUS;
    meshRef.current.rotation.y = -currentAngle - Math.PI / 2;
  });

  return (
    <mesh ref={meshRef}>
      <planeGeometry args={[0.8, 1.2]} />
      <meshBasicMaterial
        ref={materialRef}
        map={texture}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

function HelixScene() {
  const groupRef = useRef<THREE.Group>(null);
  const rotationSpeed = useRef(0);
  const isDragging = useRef(false);
  const lastX = useRef(0);
  const { viewport } = useThree();

  const textures = useTexture(IMAGE_PATHS);

  const helixData = useMemo<HelixItemData[]>(() => {
    const data: HelixItemData[] = [];
    for (let i = 0; i < NUM_ITEMS; i++) {
      const strand = i % 2;
      const indexOnStrand = Math.floor(i / 2);
      const angle =
        (indexOnStrand / (NUM_ITEMS / 2)) * Math.PI * 2 * TURNS;
      const y =
        (indexOnStrand / (NUM_ITEMS / 2)) * STRAND_HEIGHT - STRAND_HEIGHT / 2;
      const xOffset = strand === 0 ? 0 : Math.PI;
      data.push({
        angle,
        y,
        xOffset,
        imageIndex: indexOnStrand % IMAGE_PATHS.length,
      });
    }
    return data;
  }, []);

  useFrame(() => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y += 0.002 + rotationSpeed.current;
    rotationSpeed.current *= 0.95;
  });

  const handlePointerDown = useCallback((e: PointerEvent) => {
    isDragging.current = true;
    lastX.current = e.clientX;
  }, []);

  const handlePointerMove = useCallback((e: PointerEvent) => {
    if (!isDragging.current) return;
    const deltaX = e.clientX - lastX.current;
    rotationSpeed.current += deltaX * 0.005;
    lastX.current = e.clientX;
  }, []);

  const handlePointerUp = useCallback(() => {
    isDragging.current = false;
  }, []);

  const handleWheel = useCallback((e: WheelEvent) => {
    rotationSpeed.current += e.deltaY * 0.001;
  }, []);

  useMemo(() => {
    if (typeof window !== 'undefined') {
      window.addEventListener('pointerdown', handlePointerDown);
      window.addEventListener('pointermove', handlePointerMove);
      window.addEventListener('pointerup', handlePointerUp);
      window.addEventListener('wheel', handleWheel, { passive: true });
      return () => {
        window.removeEventListener('pointerdown', handlePointerDown);
        window.removeEventListener('pointermove', handlePointerMove);
        window.removeEventListener('pointerup', handlePointerUp);
        window.removeEventListener('wheel', handleWheel);
      };
    }
  }, [handlePointerDown, handlePointerMove, handlePointerUp, handleWheel]);

  const fov = useMemo(() => {
    return 2 * Math.atan(viewport.height / 2 / 6) * (180 / Math.PI);
  }, [viewport.height]);

  return (
    <>
      <perspectiveCamera position={[0, 0, 6]} fov={fov} />
      <mesh>
        <sphereGeometry args={[15, 64, 64]} />
        <meshBasicMaterial color="#1a1a1a" side={THREE.BackSide} />
      </mesh>
      <ambientLight intensity={0.6} color="#f5e6d0" />
      <group ref={groupRef}>
        {helixData.map((data, i) => (
          <HelixMesh
            key={i}
            texture={textures[data.imageIndex]}
            data={data}
            groupRef={groupRef}
          />
        ))}
      </group>
    </>
  );
}

export default function HelixGallery() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 50 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: false }}
        style={{ background: '#1a1a1a' }}
      >
        <HelixScene />
      </Canvas>
    </div>
  );
}
