import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const SERVICES = [
  {
    num: '01',
    title: 'Arch Design',
    desc: 'From initial concept development and schematic design through construction documentation',
    image: '/images/svc-arch.jpg',
  },
  {
    num: '02',
    title: 'Interior Design',
    desc: 'Creating cohesive interior spaces that reflect your style, culture, and daily rituals',
    image: '/images/svc-interior.jpg',
  },
  {
    num: '03',
    title: 'Urban Planning',
    desc: 'Designing the spaces between buildings — landscapes, plazas, and connections',
    image: '/images/svc-urban.jpg',
  },
  {
    num: '04',
    title: 'Project Management',
    desc: 'Overseeing and controlling the entire construction process from groundbreaking to final walkthrough',
    image: '/images/svc-project.jpg',
  },
];

export default function ServicesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      if (!scrollRef.current) return;
      const cards = scrollRef.current.querySelectorAll('.service-card');
      gsap.from(cards, {
        x: 60,
        opacity: 0,
        duration: 0.7,
        ease: 'power3.out',
        stagger: 0.12,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });
    },
    { scope: sectionRef }
  );

  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const amount = dir === 'left' ? -320 : 320;
    scrollRef.current.scrollBy({ left: amount, behavior: 'smooth' });
  };

  return (
    <section
      id="services"
      ref={sectionRef}
      className="w-full py-[120px] bg-white"
    >
      <div className="max-w-[1200px] mx-auto px-8 lg:px-12">
        <div className="flex items-center justify-between mb-10">
          <h2 className="font-display text-4xl font-normal text-[#1a1a1a]">
            Services we provide
          </h2>
          <div className="flex gap-2">
            <button
              onClick={() => scroll('left')}
              className="w-10 h-10 rounded-full border border-[#e0dcd3] flex items-center justify-center transition-colors hover:bg-[#f5f2ec]"
            >
              <ChevronLeft className="w-4 h-4 text-[#1a1a1a]" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="w-10 h-10 rounded-full border border-[#e0dcd3] flex items-center justify-center transition-colors hover:bg-[#f5f2ec]"
            >
              <ChevronRight className="w-4 h-4 text-[#1a1a1a]" />
            </button>
          </div>
        </div>

        <div
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto hide-scrollbar pb-4"
        >
          {SERVICES.map((svc) => (
            <div
              key={svc.num}
              className="service-card flex-shrink-0 w-[280px] group"
            >
              <div className="w-[280px] h-[200px] rounded-lg overflow-hidden">
                <img
                  src={svc.image}
                  alt={svc.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
              </div>
              <span className="font-mono text-xs text-[#666666] mt-4 block">
                {svc.num}
              </span>
              <h3 className="font-body text-lg font-medium text-[#1a1a1a] mt-2">
                {svc.title}
              </h3>
              <p className="font-body text-sm font-normal text-[#666666] mt-2 line-clamp-2">
                {svc.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
