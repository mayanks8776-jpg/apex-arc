import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(ScrollTrigger);

const STATS = [
  { value: '25+', label: 'Years of Excellence in Architecture & Design' },
  { value: '500+', label: 'Projects Successfully Completed' },
  { value: '98%', label: 'Our Client Retention Rate' },
  { value: '15+', label: 'Countries with Our Projects' },
];

const PARTNERS = ['CNBC', 'ARCHITECTURAL DIGEST', 'DEZEEN', 'WALLPAPER*'];

export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      if (!leftRef.current || !statsRef.current) return;

      gsap.from(leftRef.current, {
        y: 40,
        opacity: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });

      const statItems = statsRef.current.querySelectorAll('.stat-item');
      gsap.from(statItems, {
        y: 40,
        opacity: 0,
        duration: 0.8,
        ease: 'power3.out',
        stagger: 0.15,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });
    },
    { scope: sectionRef }
  );

  return (
    <section
      id="about"
      ref={sectionRef}
      className="w-full py-[120px] bg-[#f9f6f0]"
    >
      <div className="max-w-[1200px] mx-auto px-8 lg:px-12 flex flex-col lg:flex-row gap-16">
        <div ref={leftRef} className="lg:w-[55%]">
          <h2 className="font-display text-4xl font-normal text-[#1a1a1a]">
            About Company
          </h2>
          <p className="font-body text-base font-normal text-[#666666] leading-relaxed mt-5 max-w-[480px]">
            At APEX Architects, we believe that architecture is more than just
            buildings; it&apos;s about creating environments that enhance human
            experience. Every project begins with deep listening — understanding
            how spaces will be lived in, worked within, and remembered.
          </p>

          <div className="flex flex-wrap items-center gap-10 mt-12">
            {PARTNERS.map((partner) => (
              <span
                key={partner}
                className="font-body text-xs font-medium text-[#999999] tracking-wider opacity-50"
              >
                {partner}
              </span>
            ))}
          </div>
        </div>

        <div ref={statsRef} className="lg:w-[45%]">
          <div className="grid grid-cols-2 gap-8">
            {STATS.map((stat) => (
              <div key={stat.label} className="stat-item">
                <span className="font-mono text-[40px] font-normal text-[#1a1a1a]">
                  {stat.value}
                </span>
                <p className="font-body text-[13px] font-normal text-[#666666] mt-1 leading-snug">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
