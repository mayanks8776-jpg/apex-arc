import { useRef, useEffect } from 'react';
import gsap from 'gsap';

const LOGOS = [
  'Gensler',
  'Foster+Partners',
  'Zaha Hadid',
  'BIG',
  'SOM',
  'Heatherwick',
  'OMA',
  'MVRDV',
];

function LogoItem({ name }: { name: string }) {
  return (
    <div className="flex items-center justify-center w-[100px] h-[50px] opacity-40 shrink-0">
      <span className="font-body text-xs font-medium text-[#1a1a1a] tracking-wider whitespace-nowrap">
        {name}
      </span>
    </div>
  );
}

export default function TrustedBySection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const row1Ref = useRef<HTMLDivElement>(null);
  const row2Ref = useRef<HTMLDivElement>(null);
  const tween1Ref = useRef<gsap.core.Tween | null>(null);
  const tween2Ref = useRef<gsap.core.Tween | null>(null);
  const baseSpeed1 = useRef(0);
  const baseSpeed2 = useRef(0);
  const velocityRef = useRef(0);
  const lastScrollRef = useRef(0);

  useEffect(() => {
    const row1 = row1Ref.current;
    const row2 = row2Ref.current;
    if (!row1 || !row2) return;

    const totalWidth1 = row1.scrollWidth / 2;
    const totalWidth2 = row2.scrollWidth / 2;

    gsap.set(row1, { x: -totalWidth1 });
    gsap.set(row2, { x: -totalWidth2 });

    tween1Ref.current = gsap.to(row1, {
      x: 0,
      duration: 1,
      ease: 'none',
      repeat: -1,
    });

    tween2Ref.current = gsap.to(row2, {
      x: -(totalWidth2 + 200),
      duration: 1,
      ease: 'none',
      repeat: -1,
    });

    tween1Ref.current.pause();
    tween2Ref.current.pause();

    // Track scroll velocity manually
    const handleScroll = () => {
      const currentScroll = window.scrollY;
      velocityRef.current = currentScroll - lastScrollRef.current;
      lastScrollRef.current = currentScroll;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    const rafId = { current: 0 };

    const animate = () => {
      baseSpeed1.current += 0.0007;
      baseSpeed2.current += 0.0007;

      const normalizedVelocity = velocityRef.current * 12;

      tween1Ref.current?.time(baseSpeed1.current + normalizedVelocity);
      tween2Ref.current?.time(baseSpeed2.current - normalizedVelocity);

      // Decay velocity
      velocityRef.current *= 0.9;

      rafId.current = requestAnimationFrame(animate);
    };

    rafId.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      cancelAnimationFrame(rafId.current);
      tween1Ref.current?.kill();
      tween2Ref.current?.kill();
    };
  }, []);

  return (
    <div ref={sectionRef} className="w-full py-[60px] bg-[#f9f6f0] overflow-hidden">
      <p className="font-body text-xs font-normal text-[#666666] uppercase tracking-[2px] text-center mb-6">
        Trusted by industry leaders
      </p>

      <div className="border-t border-b border-[#e0dcd3] py-6 space-y-4">
        <div className="overflow-hidden">
          <div ref={row1Ref} className="logo-scroll-row gap-16">
            {[...LOGOS, ...LOGOS].map((name, i) => (
              <LogoItem key={`r1-${i}`} name={name} />
            ))}
          </div>
        </div>

        <div className="overflow-hidden">
          <div ref={row2Ref} className="logo-scroll-row gap-16" style={{ marginLeft: '-200px' }}>
            {[...LOGOS.reverse(), ...LOGOS].map((name, i) => (
              <LogoItem key={`r2-${i}`} name={name} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
