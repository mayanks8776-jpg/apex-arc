import { Instagram, Linkedin, Twitter } from 'lucide-react';

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Portfolio', href: '#portfolio' },
  { label: 'Process', href: '#stats' },
  { label: 'Contact', href: '#contact' },
];

export default function Footer() {
  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#1a1a1a] py-[60px] px-8 lg:px-12">
      <div className="max-w-[1200px] mx-auto">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <span className="font-display text-xl text-[#f9f6f0]">APEX Arc</span>

          <nav className="flex flex-wrap gap-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleClick(e, link.href)}
                className="font-body text-sm font-normal text-[rgba(249,246,240,0.6)] transition-colors hover:text-[#f9f6f0]"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="border-t border-[#333333] my-8" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <p className="font-body text-xs text-[rgba(249,246,240,0.4)]">
            2026 APEX Arc. All rights reserved.
          </p>

          <div className="flex items-center gap-6">
            <a
              href="#"
              className="text-[rgba(249,246,240,0.4)] transition-colors hover:text-[#f9f6f0]"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a
              href="#"
              className="text-[rgba(249,246,240,0.4)] transition-colors hover:text-[#f9f6f0]"
            >
              <Linkedin className="w-5 h-5" />
            </a>
            <a
              href="#"
              className="text-[rgba(249,246,240,0.4)] transition-colors hover:text-[#f9f6f0]"
            >
              <Twitter className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
