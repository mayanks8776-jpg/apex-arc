import HelixGallery from '../components/HelixGallery';
import { ChevronDown } from 'lucide-react';

export default function HeroSection() {
  const handleCTA = () => {
    const el = document.querySelector('#contact');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative w-full h-screen overflow-hidden">
      <HelixGallery />

      <div
        className="relative z-10 flex flex-col items-center justify-center h-full px-4"
        style={{ pointerEvents: 'none' }}
      >
        <h1
          className="font-display text-4xl sm:text-5xl lg:text-[56px] font-normal text-white text-center leading-[1.1]"
          style={{ textShadow: '0 2px 40px rgba(0,0,0,0.3)' }}
        >
          Designing Spaces
          <br />
          That Inspire &amp; Endure
        </h1>

        <p
          className="font-body text-base font-normal text-white/85 text-center max-w-[480px] mt-5"
          style={{ textShadow: '0 1px 20px rgba(0,0,0,0.3)' }}
        >
          We transform visions into timeless architecture, blending innovative
          design with functional excellence
        </p>

        <button
          onClick={handleCTA}
          className="mt-8 px-8 py-3.5 bg-white text-[#1a1a1a] rounded-full font-body text-sm font-medium transition-all duration-300 hover:bg-[#1a1a1a] hover:text-white"
          style={{ pointerEvents: 'auto' }}
        >
          Schedule a Free Consultation
        </button>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce-chevron">
        <ChevronDown className="w-5 h-5 text-white/50" />
      </div>
    </section>
  );
}
