import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(ScrollTrigger);

const PROJECTS = [
  {
    name: 'Horizon Residence',
    type: 'Private House',
    location: 'Malibu, CA',
    image: '/images/port-horizon.jpg',
    tall: true,
  },
  {
    name: 'Nexus Tower',
    type: 'Commercial Restaurant',
    location: 'Chicago, IL',
    image: '/images/port-nexus.jpg',
    tall: false,
  },
  {
    name: 'The Meridian',
    type: 'Hotel Rooms',
    location: 'Miami Beach, FL',
    image: '/images/port-meridian.jpg',
    tall: false,
  },
  {
    name: 'Catalyst Campus',
    type: 'New York Office',
    location: 'Manhattan, NY',
    image: '/images/port-catalyst.jpg',
    tall: false,
  },
  {
    name: 'Stillwater Villa',
    type: 'Private House',
    location: 'Aspen, CO',
    image: '/images/port-stillwater.jpg',
    tall: false,
  },
];

const STRIP_COUNT = 5;

function FoldGridItem({
  project,
  className = '',
}: {
  project: (typeof PROJECTS)[0];
  className?: string;
}) {
  const itemRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = itemRef.current;
    if (!el) return;

    const strips = el.querySelectorAll<HTMLElement>('.fold-outer');
    if (strips.length === 0) return;

    const intervalPixels = 100;
    const totalStrips = STRIP_COUNT;
    const totalHeight = window.innerHeight;
    const totalScrollDistance = totalStrips * intervalPixels + totalHeight;
    const initialX = -20 * totalStrips;
    const middleIndex = Math.floor(totalStrips / 2);

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: el,
        start: 'top bottom',
        end: `+=${totalScrollDistance}`,
        scrub: true,
      },
    });

    // Phase 1: Stagger in
    strips.forEach((strip, index) => {
      tl.fromTo(
        strip,
        {
          y: 100,
          x: initialX + index * 20,
          rotationZ: -5,
          scale: 0.5,
        },
        {
          y: 0,
          x: 0,
          rotationZ: 0,
          scale: 1,
          ease: 'none',
        },
        index * (intervalPixels / totalScrollDistance)
      );
    });

    // Phase 2: Fold outward
    const foldTl = gsap.timeline();
    strips.forEach((strip, index) => {
      const inner = strip.querySelector<HTMLElement>('.fold-inner');
      if (!inner) return;

      gsap.set(strip.parentElement, { perspective: 1000 });

      let transformOrigin: string;
      let targetRotationY: number;

      if (index < middleIndex) {
        transformOrigin = `0% 50% ${-(middleIndex - index) * 50}px`;
        targetRotationY = 70 + index * 10;
      } else if (index === middleIndex) {
        transformOrigin = '50% 50%';
        targetRotationY = 0;
      } else {
        transformOrigin = `100% 50% ${(index - middleIndex) * 50}px`;
        targetRotationY = -(70 + (totalStrips - 1 - index) * 10);
      }

      gsap.set(inner, { transformOrigin });

      foldTl.fromTo(
        inner,
        { rotationY: 0 },
        {
          rotationY: targetRotationY,
          ease: 'power1.inOut',
          duration: (intervalPixels * 5) / totalScrollDistance,
        },
        index * 0.02
      );
    });

    tl.add(foldTl, '+=0.1');

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <div ref={itemRef} className={`relative overflow-hidden rounded-lg ${className}`}>
      <div className="flex w-full h-full">
        {Array.from({ length: STRIP_COUNT }, (_, i) => (
          <div key={i} className="fold-outer flex-1 h-full overflow-hidden" style={{ willChange: 'transform' }}>
            <div
              className="fold-inner w-full h-full"
              style={{
                backgroundImage: `url(${project.image})`,
                backgroundSize: 'cover',
                backgroundPositionX: `${i * 25}%`,
                willChange: 'transform',
              }}
            />
          </div>
        ))}
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/40 to-transparent">
        <h3 className="font-body text-base font-medium text-white">
          {project.name}
        </h3>
        <p className="font-body text-xs font-normal text-white/70">
          {project.type}
        </p>
      </div>
    </div>
  );
}

export default function PortfolioSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      if (!headerRef.current) return;
      gsap.from(headerRef.current, {
        y: 40,
        opacity: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });
    },
    { scope: sectionRef }
  );

  return (
    <section
      id="portfolio"
      ref={sectionRef}
      className="w-full py-[120px] bg-[#f9f6f0]"
    >
      <div className="max-w-[1200px] mx-auto px-8 lg:px-12">
        <div ref={headerRef} className="mb-10">
          <h2 className="font-display text-4xl font-normal text-[#1a1a1a]">
            Our Portfolio of
            <br />
            Pioneering Design
          </h2>
          <p className="font-body text-sm font-normal text-[#666666] max-w-[360px] mt-3">
            Explore our selected works that demonstrate our commitment to design
            excellence, innovation, and client satisfaction
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 auto-rows-[280px]">
          {/* Left tall item */}
          <FoldGridItem
            project={PROJECTS[0]}
            className="md:row-span-2"
          />

          {/* Right column items */}
          <FoldGridItem project={PROJECTS[1]} />
          <FoldGridItem project={PROJECTS[2]} />

          {/* Bottom row */}
          <FoldGridItem project={PROJECTS[3]} />

          {/* Last item with button overlay */}
          <div className="relative">
            <FoldGridItem project={PROJECTS[4]} className="h-full" />
            <div className="absolute bottom-4 right-4 z-10">
              <button className="px-7 py-3.5 bg-[#1a1a1a] text-white rounded-lg font-body text-sm font-medium transition-colors hover:bg-[#333333]">
                See More Projects
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
