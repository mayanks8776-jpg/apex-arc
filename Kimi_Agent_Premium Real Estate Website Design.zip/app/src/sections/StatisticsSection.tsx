import { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface StatData {
  value: string;
  label: string;
  digits: number[];
}

const STATS: StatData[] = [
  { value: '25', label: 'Years of Architectural Excellence', digits: [2, 5] },
  { value: '500', label: 'Projects Successfully Delivered', digits: [5, 0, 0] },
  { value: '98', label: 'Client Retention Rate (%)', digits: [9, 8] },
  { value: '15', label: 'Countries with Active Projects', digits: [1, 5] },
];

function SlotMachineDigit({
  finalDigit,
  delay,
  trigger,
}: {
  finalDigit: number;
  delay: number;
  trigger: boolean;
}) {
  const stripRef = useRef<HTMLDivElement>(null);
  const [displayDigits, setDisplayDigits] = useState<number[]>(
    Array.from({ length: 10 }, (_, i) => i)
  );

  useEffect(() => {
    if (!trigger || !stripRef.current) return;

    const strip = stripRef.current;
    const targetY = -(finalDigit * 10);

    // Animate from far above to target
    gsap.fromTo(
      strip,
      { yPercent: -1000 },
      {
        yPercent: targetY,
        duration: 2.5,
        ease: 'power2.inOut',
        delay,
        onUpdate: function () {
          // Randomize digits during animation for slot-machine effect
          if (this.progress() < 0.8) {
            setDisplayDigits((prev) =>
              prev.map(() => Math.floor(Math.random() * 10))
            );
          } else {
            // Settle on correct digits
            setDisplayDigits(Array.from({ length: 10 }, (_, i) => i));
          }
        },
      }
    );

    // Blur effect
    gsap.fromTo(
      strip,
      { filter: 'blur(2px)' },
      {
        filter: 'blur(0px)',
        duration: 2.5,
        ease: 'power2.inOut',
        delay,
      }
    );
  }, [trigger, finalDigit, delay]);

  return (
    <div className="digit-column font-mono text-6xl lg:text-7xl font-normal text-[#f9f6f0] leading-none">
      <div ref={stripRef} className="digit-strip">
        {displayDigits.map((d, i) => (
          <span key={i}>{d}</span>
        ))}
      </div>
    </div>
  );
}

function SlotMachineStat({
  stat,
  index,
  trigger,
}: {
  stat: StatData;
  index: number;
  trigger: boolean;
}) {
  return (
    <div className="text-center">
      <div className="flex justify-center items-center">
        {stat.digits.map((digit, i) => (
          <SlotMachineDigit
            key={i}
            finalDigit={digit}
            delay={index * 0.3 + i * 0.15}
            trigger={trigger}
          />
        ))}
      </div>
      <p className="font-body text-sm font-normal text-[rgba(249,246,240,0.6)] mt-3">
        {stat.label}
      </p>
    </div>
  );
}

export default function StatisticsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [triggered, setTriggered] = useState(false);

  useEffect(() => {
    if (!sectionRef.current) return;

    const trigger = ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top 70%',
      onEnter: () => setTriggered(true),
      once: true,
    });

    return () => trigger.kill();
  }, []);

  return (
    <section
      id="stats"
      ref={sectionRef}
      className="w-full py-[100px] bg-[#1a1a1a] relative overflow-hidden"
    >
      {/* Subtle noise texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
        }}
      />

      <div className="relative z-10 max-w-[1200px] mx-auto px-8 lg:px-12">
        <h2 className="font-display text-4xl font-normal text-[#f9f6f0] text-center">
          Our Impact in Numbers
        </h2>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-20 mt-16 justify-items-center">
          {STATS.map((stat, i) => (
            <SlotMachineStat
              key={stat.label}
              stat={stat}
              index={i}
              trigger={triggered}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
