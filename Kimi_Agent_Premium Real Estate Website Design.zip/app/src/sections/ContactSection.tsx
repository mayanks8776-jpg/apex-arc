import { useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { Mail, Phone, MapPin } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectType: 'Residential',
    message: '',
  });

  useGSAP(
    () => {
      if (!leftRef.current || !rightRef.current) return;

      gsap.from(leftRef.current, {
        x: -40,
        opacity: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });

      gsap.from(rightRef.current, {
        x: 40,
        opacity: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });
    },
    { scope: sectionRef }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your inquiry! We will get back to you soon.');
    setFormData({ name: '', email: '', projectType: 'Residential', message: '' });
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="w-full py-[120px] bg-[#f9f6f0]"
    >
      <div className="max-w-[1200px] mx-auto px-8 lg:px-12 flex flex-col lg:flex-row gap-16">
        <div ref={leftRef} className="lg:w-1/2">
          <h2 className="font-display text-4xl font-normal text-[#1a1a1a]">
            Let&apos;s Build Something
            <br />
            Extraordinary
          </h2>
          <p className="font-body text-base font-normal text-[#666666] mt-5">
            Whether you&apos;re envisioning a private residence, a commercial
            landmark, or an urban masterplan, we&apos;d love to hear about your
            project.
          </p>

          <div className="mt-12 space-y-4">
            <div className="flex items-center gap-3">
              <Mail className="w-4 h-4 text-[#666666]" />
              <span className="font-body text-base font-normal text-[#1a1a1a]">
                hello@apexarc.com
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="w-4 h-4 text-[#666666]" />
              <span className="font-body text-base font-normal text-[#1a1a1a]">
                +1 (310) 555-0147
              </span>
            </div>
            <div className="flex items-center gap-3">
              <MapPin className="w-4 h-4 text-[#666666]" />
              <span className="font-body text-base font-normal text-[#1a1a1a]">
                Los Angeles, CA
              </span>
            </div>
          </div>
        </div>

        <div ref={rightRef} className="lg:w-1/2">
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              placeholder="Your Name"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              className="w-full h-12 bg-white border border-[#e0dcd3] rounded-lg px-4 font-body text-sm text-[#1a1a1a] placeholder:text-[#999999] focus:outline-none focus:border-[#1a1a1a] transition-colors"
            />
            <input
              type="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
              className="w-full h-12 bg-white border border-[#e0dcd3] rounded-lg px-4 font-body text-sm text-[#1a1a1a] placeholder:text-[#999999] focus:outline-none focus:border-[#1a1a1a] transition-colors"
            />
            <select
              value={formData.projectType}
              onChange={(e) =>
                setFormData({ ...formData, projectType: e.target.value })
              }
              className="w-full h-12 bg-white border border-[#e0dcd3] rounded-lg px-4 font-body text-sm text-[#1a1a1a] focus:outline-none focus:border-[#1a1a1a] transition-colors appearance-none cursor-pointer"
            >
              <option>Residential</option>
              <option>Commercial</option>
              <option>Hospitality</option>
              <option>Urban Planning</option>
              <option>Other</option>
            </select>
            <textarea
              placeholder="Tell us about your project..."
              value={formData.message}
              onChange={(e) =>
                setFormData({ ...formData, message: e.target.value })
              }
              className="w-full h-[120px] bg-white border border-[#e0dcd3] rounded-lg px-4 py-3 font-body text-sm text-[#1a1a1a] placeholder:text-[#999999] focus:outline-none focus:border-[#1a1a1a] transition-colors resize-none"
            />
            <button
              type="submit"
              className="w-full h-12 bg-[#1a1a1a] text-white rounded-lg font-body text-sm font-medium transition-colors hover:bg-[#333333]"
            >
              Send Inquiry
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
